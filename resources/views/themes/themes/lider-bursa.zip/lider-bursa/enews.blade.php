@extends($theme_path . '.frontend_layout')

@section('custom_css')
    <style>
        .header {
            /* background-color: #0000ff; */
            color: white;
            padding: 10px 20px;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }

        .badge-custom {
            background-color: yellow;
            color: black;
            font-size: 12px;
            font-weight: bold;
            padding: 3px 6px;
            position: absolute;
            top: 10px;
            left: 10px;
        }

        .search-section {
            background: linear-gradient(to right, #ffe742, #ff8d43);
            /* Sarıdan turuncuya geçiş */
            padding: 15px;
            border-radius: 5px;
        }

        .card-img, .card-img-top, .card-img-bottom {
                width: 100%;
                min-height: 666px;
            }


        /* Mobil uyumluluk */
        @media (max-width: 768px) {
            .search-section {
                flex-direction: column;
                gap: 10px;
            }
            .card-img, .card-img-top, .card-img-bottom {
                width: 50%;
                min-height: auto;
            }

        }
    </style>
@endsection

@section('content')
    <div class="container my-4">

        <div class="row g-3">

            @foreach ($enews as $news)

                <div class="col-12 col-sm-6 col-md-4">
                    <div class="card position-relative text-center">
                        <a href="{{route('home.enews-detail', ['id' => $news->id])}}">
                            <img src="{{ imageCheck($news->images) }}" class="card-img-top" alt="{{ $news->title }}" width = "100%" height="auto"
                                onerror="this.onerror=null;this.src='/resimler/enews_blank.png'">
                            <div class="card-body text-center">
                                <h5 class="card-title text-uppercase">{{ $news->title }}</h5>
                            </div>
                        </a>

                    </div>
                </div>
            @endforeach




        </div>


    </div>
    </div>
@endsection
