
header yazı rengi ne ise yandaki butonları o renge bagla ( SVG RESİM OLARAK KULLANILMIŞ BU YÜZDEN RENK DEĞİŞMİYOR )
